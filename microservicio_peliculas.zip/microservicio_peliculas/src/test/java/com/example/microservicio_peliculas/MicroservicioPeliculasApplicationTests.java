package com.example.microservicio_peliculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioPeliculasApplicationTests {

	@Test
	void contextLoads() {
	}

}
