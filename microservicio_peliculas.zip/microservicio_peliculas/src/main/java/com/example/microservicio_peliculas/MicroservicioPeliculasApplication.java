package com.example.microservicio_peliculas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioPeliculasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioPeliculasApplication.class, args);
	}

}
